{ pkgs, user, ... }: {
  programs.zsh.enable = true;

  users = {
    defaultUserShell = pkgs.zsh;
    users.${user} = {
      isNormalUser = true;
      extraGroups = [ "wheel" "networkmanager" ];
    };
    users.alice = {
      isNormalUser = true;
      extraGroups = ["wheel" "networkmanager" ];
    };
  };

}
