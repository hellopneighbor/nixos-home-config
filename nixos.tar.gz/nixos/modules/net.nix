{
  networking.networkmanager.enable = true;
}
